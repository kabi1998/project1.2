  
from import_export import resources
from .models import subho

class subhoResource(resources.ModelResource):
    class Meta:
        model = subho