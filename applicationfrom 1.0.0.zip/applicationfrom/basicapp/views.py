from django.shortcuts import render
from django.http import HttpResponse
from .models import subho
from .resources import subhoResource
from tablib import Dataset


# Create your views here.
def base(request):
    return render(request,"base.html")
def index(request):
    if request.method=="POST":
        print("post method is applied sucessfully")
        firstname=request.POST["firstname"]
        lastname=request.POST["lastname"]
        dob=request.POST["dob"]
        gender=request.POST["gender"]
        town=request.POST["town"]
        district=request.POST["district"]
        state=request.POST["state"]
        subho_1=subho(firstname=firstname,lastname=lastname,dob=dob,gender=gender
        ,town=town,district=district,state=state)
        subho_1.save()

    return render(request,"ApplicationFrom.html")

def login(request):
    return render(request,"login.html")

def export(request):
    subho_resource = subhoResource()
    dataset = subho_resource.export()
    response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename="student_database.xls'
    return response

def simple_upload(request):
    if request.method == 'POST':
        subho_resource = subhoResource()
        dataset = Dataset()
        new_persons = request.FILES['myfile']

        imported_data = dataset.load(new_persons.read(),format='xlsx')
        #print(imported_data)
        for data in imported_data:
        	print(data[1])
        	value = subho(
        		data[0],
        		data[1],
        		 data[2],
        		 data[3],
                 data[4],
                 data[5],
                 data[6]
        		)
        	value.save()       
        
        #result = person_resource.import_data(dataset, dry_run=True)  # Test the data import

        #if not result.has_errors():
        #    person_resource.import_data(dataset, dry_run=False)  # Actually import now

    return render(request, 'input.html')