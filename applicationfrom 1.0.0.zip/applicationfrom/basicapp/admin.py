from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import subho

# Register your models here.
# admin.site.register(subho)
@admin.register(subho)
class subhoAdmin(ImportExportModelAdmin):
    list_display = ('firstname', 'lastname', 'dob','gender','town','district','state')
