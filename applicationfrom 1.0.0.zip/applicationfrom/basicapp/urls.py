
from django.urls import  path
from . import views




urlpatterns = [
    path('',views.base,name="base"),
    path('index/',views.index,name="index"),
    path('login/',views.login,name="login"),
    path('export/',views.export,name="export"),
    path('simple_upload/',views.simple_upload,name='simple_upload')
]