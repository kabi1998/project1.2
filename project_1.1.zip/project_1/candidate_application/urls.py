from django.contrib import admin
from django.urls import path
from candidate_application import views

urlpatterns = [
    path('candidate/',views.candidate_application,name='candidate_application'),

]