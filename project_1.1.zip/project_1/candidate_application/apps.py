from django.apps import AppConfig


class CandidateApplicationConfig(AppConfig):
    name = 'candidate_application'
