from __future__ import unicode_literals  
from django.db import models


# Create your models here.
GENDER_CHOICES = (
    ('male', 'male'),
    ('female', 'female'),
)

POST_GRADUATION = (
    ('no', 'no'),
    ('yes', 'yes'),
)

FRESHER = (
    ('no','no'),
    ('yes' ,'yes'),
)

HAVING_LAPTOP = (
    ('no', 'no'),
    ('yes' ,'yes'),
    ('not found' , 'not found'),
)
PURPUSE_VISIT = (
     ('internship','internship'),
     ('clp','clp'),
 )

DOMAIN_INTEREST = (
     ('python','python'),
     ('java','java'),
     ('php','php'),
     ('data science','data science'),
 )

SIBLING_WORKING = (
     ('student','student'),
     ('working' , 'working'),
     ('not found','not found'),
 )

DOMAIN_KNOWLEDGE = (
     ('no','no'),
     ('yes','yes'),
 )

JIONED_Y_N = (
     ('no','no'),
     ('yes','yes'),
 )

GRADUATE_DEGREE = (
    ('btech' ,'btech'),
    ('be' ,'be'),
    ('bcom','bcom'),
    ('bstat','bstat'),
    ('bba','bba'),
    ('bca','bca'),
    ('bsc','bsc'),
    ('others','others'),
    ('not found' , 'not found'),
)
POST_GRADUATE_DEGREE =(
    ('mtech' ,'mtech'),
    ('me','me'),
    ('mcom','mcom'),
    ('mstat','mstat'),
    ('mba','mba'),
    ('mca','mca'),
    ('msc','msc'),
    ('others','others'),
    ('not done','not done'),
)
GRADUATION_STREAM = (
    ('cse','cse'),
    ('ee','ee'),
    ('ece','ece'),
    ('ce','ce'),
    ('eee','eee'),
    ('me','me'),
    ('others','others'),
)
POST_GRADUATION_STREAM =(
    ('no stream','no stream'),
    ('cse','cse'),
    ('ee','ee'),
    ('ece','ece'),
    ('ce','ce'),
    ('eee','eee'),
    ('me','me'),
    ('others','others'),
)
STATES_LOCATION = (
    ('Andhra Pradesh','Andhra Pradesh'),
    ('Arunachal Pradesh','Arunachal Pradesh'),
    ('Assam','Assam'),
    ('Bihar','Bihar'),
    ('Chhattisgarh','Chhattisgarh'),
    ('Goa','Goa'),
    ('Gujarat','Gujarat'),
    ('Haryana','Haryana'),
    ('Himachal Pradesh','Himachal Pradesh'),
    ('Jharkhand','Jharkhand'),
    ('Karnataka','Karnataka'),
    ('Kerala','Kerala'),
    ('Madhya Pradesh', 'Madhya Pradesh'),
    ('Maharashtra','Maharashtra'),
    ('Manipur','Manipur'),
    ('Meghalaya','Meghalaya'),
    ('Mizoram','Mizoram'),
    ('Nagaland','Nagaland'),
    ('Odisha','Odisha'),
    ('Punjab','Punjab'),
    ('Rajasthan','Rajasthan'),
    ('Sikkim','Sikkim'),
    ('Tamil Nadu','Tamil Nadu'),
    ('Tripura','Tripura'),
    ('Uttar Pradesh','Uttar Pradesh'),
    ('Uttarakhand','Uttarakhand'),
    ('West Bengal','West Bengal'),
)

REFERENCE_SOURCE = (
    ('LinkedIn','LinkedIn'),
    ('Facebook','Facebook'),
    ('Consultancy','Consultancy'),
    ('Job Portal','Job Portal'),
    ('Others','Others'),
)

class Candidate(models.Model):  
    name = models.CharField(max_length=50)  
    gender  = models.CharField(max_length=50 ,choices=GENDER_CHOICES) 
    last_passout_year    = models.IntegerField()  
    graduate_degree = models.CharField(max_length=50 ,choices=GRADUATE_DEGREE)
    pg_degree = models.CharField(max_length=50 ,choices=POST_GRADUATE_DEGREE)
    graduate_stream = models.CharField(max_length=50 ,choices=GRADUATION_STREAM)
    pg_stream = models.CharField(max_length=20, choices =POST_GRADUATION_STREAM )
    pg_yes_or_no = models.CharField(max_length=50 ,choices = POST_GRADUATION )
    it_exp_months = models.IntegerField()
    non_it_exp_months = models.IntegerField()
    freshers = models.CharField(max_length=50 ,choices = FRESHER )
    marks_10th_percent = models.DecimalField( max_digits=5, decimal_places=2)
    marks_12th_percent = models.DecimalField( max_digits=5, decimal_places=2)
    graduate_cgpa = models.DecimalField( max_digits=5, decimal_places=2)
    pg_cgpa = models.DecimalField( max_digits=5, decimal_places=2)
    aptitude_score = models.DecimalField( max_digits=5, decimal_places=2)
    have_laptop = models.CharField(max_length=50 ,choices = HAVING_LAPTOP)
    state_location = models.CharField(max_length=50 ,choices = STATES_LOCATION)
    district_location = models.CharField(max_length=25)
    purpuse_of_visit = models.CharField(max_length=50 ,choices = PURPUSE_VISIT )
    college_name = models.CharField(max_length=50)
    pg_college = models.CharField(max_length=50)
    domain_interested = models.CharField(max_length=50 ,choices = DOMAIN_INTEREST)
    fathers_occupation = models.CharField(max_length=50)
    mothers_occupation = models.CharField(max_length=50)
    no_of_siblings = models.IntegerField()
    siblings_working = models.CharField(max_length=20 ,choices = SIBLING_WORKING)
    domain_Knowledge = models.CharField(max_length=50 ,choices = DOMAIN_KNOWLEDGE)
    previous_interviews_no = models.IntegerField()
    selected_interviews = models.IntegerField()
    reference_source = models.CharField(max_length=50 ,choices = REFERENCE_SOURCE)
    status = models.CharField(max_length=50)
    joined_yes_no = models.CharField(max_length=50 ,choices = JIONED_Y_N)

    class Meta:
        db_table = "candidate" 
