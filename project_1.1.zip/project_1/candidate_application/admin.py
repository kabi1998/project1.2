from django.contrib import admin
from candidate_application.models import Candidate

# Register your models here.
admin.site.register(Candidate)

