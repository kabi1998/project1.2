from django.shortcuts import render
from candidate_application.models import Candidate

# Create your views here.
def candidate_application(request):
    if request.method=="POST":

        name = request.POST['name']
        gender  = request.POST['gender']
        last_passout_year = request.POST['last_passout_year']
        graduate_degree = request.POST['graduate_degree']
        pg_degree = request.POST['pg_degree']
        graduate_stream = request.POST['graduate_stream']
        pg_stream = request.POST['pg_stream']
        pg_yes_or_no = request.POST['pg_yes_or_no']
        it_exp_months = request.POST['it_exp_months']
        non_it_exp_months = request.POST['non_it_exp_months']
        freshers = request.POST['freshers']
        marks_10th_percent = request.POST['marks_10th_percent']
        marks_12th_percent = request.POST['marks_12th_percent']
        graduate_cgpa = request.POST['graduate_cgpa']
        pg_cgpa = request.POST['pg_cgpa']
        aptitude_score =request.POST['aptitude_score']
        have_laptop = request.POST['have_laptop']
        state_location = request.POST['state_location']
        district_location = request.POST['district_location']
        purpuse_of_visit =   request.POST['purpuse_of_visit']
        college_name = request.POST['college_name']
        pg_college = request.POST['pg_college']
        domain_interested = request.POST['domain_interested']
        fathers_occupation = request.POST['fathers_occupation']
        mothers_occupation =request.POST['mothers_occupation']
        no_of_siblings = request.POST['no_of_siblings']
        siblings_working = request.POST['siblings_working']
        domain_Knowledge = request.POST['domain_Knowledge']
        previous_interviews_no = request.POST['previous_interviews_no']
        selected_interviews = request.POST['selected_interviews']
        reference_source = request.POST['reference_source']
        status = request.POST['status']
        joined_yes_no = request.POST['joined_yes_no']

        candidate_1=Candidate(name=name,gender=gender,last_passout_year=last_passout_year,
        graduate_degree=graduate_degree,pg_degree=pg_degree,graduate_stream=graduate_stream,pg_stream=pg_stream,
        pg_yes_or_no=pg_yes_or_no,it_exp_months=it_exp_months,non_it_exp_months=non_it_exp_months,freshers=freshers,
        marks_10th_percent=marks_10th_percent,marks_12th_percent=marks_12th_percent,graduate_cgpa=graduate_cgpa,pg_cgpa=pg_cgpa,
        aptitude_score=aptitude_score,have_laptop=have_laptop,state_location=state_location,district_location=district_location,
        purpuse_of_visit=purpuse_of_visit,college_name=college_name,domain_interested=domain_interested,fathers_occupation=fathers_occupation,mothers_occupation=mothers_occupation,
        no_of_siblings=no_of_siblings,siblings_working=siblings_working,domain_Knowledge=domain_Knowledge,previous_interviews_no=previous_interviews_no,selected_interviews=selected_interviews,
        reference_source=reference_source,status=status,joined_yes_no=joined_yes_no)
        candidate_1.save()

    return render(request,"candidate.html")
