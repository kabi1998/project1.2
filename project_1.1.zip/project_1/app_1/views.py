from django.shortcuts import render
from django.http import HttpResponse
from bokeh.plotting import figure, output_file, gridplot, show
from bokeh.embed import components
import pandas as pd
import numpy as np
from bokeh.models import ColumnDataSource
from bokeh.palettes import Spectral6
from bokeh.layouts import row
from math import pi
from bokeh.palettes import Category20c
from bokeh.transform import cumsum
from candidate_application.models import Candidate
# Create your views here.

def home(request):
    df=pd.read_excel("C:/Users/CHANDRASEKHAR/Desktop/kpi project/kpi.xlsx")
#     df=Candidate.objects.all()
    if request.method=='GET':
        print("post method is applied")
        year=request.GET.get("year")
        print(year) 
        df['LastPassoutYear']=df['LastPassoutYear'].astype('str')
        df=df[df['LastPassoutYear']==year]
        kata=df["Purpuse_of_visit"].value_counts()
        fruits,counts=list(kata.index),list(kata.values)
        print(fruits,counts)
        source = ColumnDataSource(data=dict(fruits=fruits, counts=counts, color=Spectral6))
        p = figure(x_range=fruits, plot_height=250, y_range=(0, 9), title="Purpose of visit vs number of students")
        p.vbar(x='fruits', top='counts', width=0.5, color='color', legend_field="fruits", source=source)
        p.legend.location = "top_right"
 ######################################################################
        pagol=df["Domain_interested"].value_counts()
        fruits,counts=list(pagol.index),list(pagol.values)
        source = ColumnDataSource(data=dict(fruits=fruits, counts=counts, color=Spectral6))
        q = figure(x_range=fruits, plot_height=250, y_range=(0, 9), title="Domain_interested vs number of students")
        q.vbar(x='fruits', top='counts', width=0.5, color='color', legend_field="fruits", source=source)
        q.legend.location = "top_right"
#####################################################################################################################
        pagol1=df["Graduate_Degree"].value_counts()
        fruits,counts=list(pagol1.index),list(pagol1.values)
        source = ColumnDataSource(data=dict(fruits=fruits, counts=counts, color=Spectral6))
        r = figure(x_range=fruits, plot_height=250, y_range=(0, 9), title="Graduate_Degree vs number of students")
        r.vbar(x='fruits', top='counts', width=0.5, color='color', legend_field="fruits", source=source)
        r.legend.location = "top_right"
 # #####################################################################################################################
        pagol3=df["State_Location"].value_counts()
        fruits,counts=list(pagol3.index),list(pagol3.values)
        source = ColumnDataSource(data=dict(fruits=fruits, counts=counts, color=Spectral6))
        s = figure(x_range=fruits, plot_height=250, y_range=(0, 9), title="State_Location vs number of students")
        s.vbar(x='fruits', top='counts', width=0.5, color='color', legend_field="fruits", source=source)
        s.legend.location = "top_right"
######################################################################################################################

        pagol4=df["District_Location"].value_counts()
        fruits,counts=list(pagol4.index),list(pagol4.values)
        source = ColumnDataSource(data=dict(fruits=fruits, counts=counts, color=Spectral6))
        t= figure(x_range=fruits, plot_height=250, y_range=(0, 9), title="District_Location vs number of students")
        t.vbar(x='fruits', top='counts', width=0.5, color='color', legend_field="fruits", source=source)
        t.legend.location = "top_right"
#########################################################################################################################
        x = { 'United States': 157, 'United Kingdom': 93, 'Japan': 89, 'China': 63,
        'Germany': 44, 'India': 42, 'Italy': 40, 'Australia': 35,
        'Brazil': 32, 'France': 31, 'Taiwan': 31, 'Spain': 29 }

        data = pd.Series(x).reset_index(name='value').rename(columns={'index':'country'})
        data['angle'] = data['value']/data['value'].sum() * 2*pi
        data['color'] = Category20c[len(x)]

        u= figure(plot_height=300, plot_width=600, title="Pie Chart", toolbar_location=None,
                tools="hover", tooltips="@country: @value")

        u.wedge(x=0, y=1, radius=0.4,
                start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
                line_color="royalblue", fill_color='color', legend='country', source=data)


  





#########################################################################################################################

        w= gridplot([[p,q],[r,s],[t,u]])
        show(w)
        script, div = components(w)
    
    return render(request,'index.html',{'script' : script , 'div' : div} )
