from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from candidate_application.models import Candidate

# Register your models here.
@admin.register(Candidate)
# admin.site.register(Candidate)
class ViewAdmin(ImportExportModelAdmin):
    exclude = ('id', )

