from django.urls import path
from app_1 import views

urlpatterns = [
    path('',views.base,name='base'),
    path('home/',views.home,name='home'),
  

]
