from django.shortcuts import render
from django.http import HttpResponse
from bokeh.plotting import figure, output_file, gridplot, show
from bokeh.embed import components
import pandas as pd
import numpy as np
from bokeh.palettes import Spectral6
from bokeh.layouts import row
from math import pi
from bokeh.palettes import Category10
from bokeh.transform import cumsum
from bokeh.io import output_notebook, show, push_notebook
from candidate_application.models import Candidate
from bokeh.models import Legend, HoverTool, LabelSet,ColumnDataSource,ranges
# Create your views here.
def base(request):
        return render(request,"homepage.html")
def home(request):
        df = pd.DataFrame(list(Candidate.objects.all().values()))
        print(df['name'])
        if request.method=='GET':
                print("post method is applied")
                year=request.GET.get("year")
                print(year) 
                df['last_passout_year']=df['last_passout_year'].astype('str')
                df=df[df['last_passout_year']==year]
                kata=df["purpuse_of_visit"].value_counts()

##############################################################################################################################################
                lang = list(kata.index)
                counts =list(kata.values)
                counts_per=[round((counts[i]/sum(counts))*100) for i in range(len(counts))]


                p = figure(x_range=lang, plot_height=450, title="Number of candidate vs purpose of visit")
                source = ColumnDataSource(dict(x=lang,y=counts_per,color=Spectral6))

                plot = figure(plot_width=600, plot_height=250, tools="save",# plot section optional
                        x_axis_label = "Poupose of visit",
                        y_axis_label = "Number of candidate",
                        title="Number of candidate vs purpose of visit",
                        x_minor_ticks=20,  #optional
                        x_range = source.data["x"],
                        y_range= ranges.Range1d(start=0,end=100))
                labels = LabelSet(x='x', y='y', text='y', level='glyph',
                        x_offset=-2.5, y_offset=0, source=source,render_mode='canvas' )# offset to adjust the height of labels

                plot.vbar(source=source,x='x',top='y',legend="x",bottom=0,width=0.3,color='color')#color optional
                
                plot.legend.orientation = "horizontal"
                plot.legend.location = "top_right"

                plot.add_layout(labels)


               

        ######################################################################
                pagol=df["domain_interested"].value_counts()
                lang,counts = list(pagol.index),list(pagol.values)
                
                counts_per=[round((counts[i]/sum(counts))*100) for i in range(len(counts))]


                p1 = figure(x_range=lang, plot_height=450, title="Number of candidate vs domain interested")
                source = ColumnDataSource(dict(x=lang,y=counts_per,color=Spectral6))

                plot1 = figure(plot_width=600, plot_height=250, tools="save",# plot section optional
                        x_axis_label = "Domain interested",
                        y_axis_label = "Number of candidate",
                        title="Number of candidate vs domain interested",
                        x_minor_ticks=20,  #optional
                        x_range = source.data["x"],
                        y_range= ranges.Range1d(start=0,end=100))
                labels = LabelSet(x='x', y='y', text='y', level='glyph',
                        x_offset=-2.5, y_offset=0, source=source,render_mode='canvas' )# offset to adjust the height of labels

                plot1.vbar(source=source,x='x',top='y',legend="x",bottom=0,width=0.3,color='color')#color optional
                
                plot1.legend.orientation = "horizontal"
                plot1.legend.location = "top_right"

                plot1.add_layout(labels)
################################################################################################################            
                pagol1=df["graduate_degree"].value_counts()
                lang,counts = list(pagol1.index),list(pagol1.values)
                
                counts_per=[round((counts[i]/sum(counts))*100) for i in range(len(counts))]


                p2 = figure(x_range=lang, plot_height=450, title="Number of candidate vs graduate degree")
                source = ColumnDataSource(dict(x=lang,y=counts_per,color=Spectral6))

                plot2 = figure(plot_width=600, plot_height=250, tools="save",# plot section optional
                        x_axis_label = "Graduate Degree",
                        y_axis_label = "Number of candidate",
                        title="Number of candidate vs graduate degree",
                        x_minor_ticks=20,  #optional
                        x_range = source.data["x"],
                        y_range= ranges.Range1d(start=0,end=100))
                labels = LabelSet(x='x', y='y', text='y', level='glyph',
                        x_offset=-2.5, y_offset=0, source=source,render_mode='canvas' )# offset to adjust the height of labels

                plot2.vbar(source=source,x='x',top='y',legend="x",bottom=0,width=0.3,color='color')#color optional
                
                plot2.legend.orientation = "horizontal"
                plot2.legend.location = "top_right"

                plot2.add_layout(labels)

        #####################################################################################################################
                pagol3=df["state_location"].value_counts()
                lang,counts = list(pagol3.index),list(pagol3.values)
                
                counts_per=[round((counts[i]/sum(counts))*100) for i in range(len(counts))]


                p3 = figure(x_range=lang, plot_height=450, title="Number of candidate vs state location")
                source = ColumnDataSource(dict(x=lang,y=counts_per,color=Spectral6))

                plot3= figure(plot_width=600, plot_height=250, tools="save",# plot section optional
                        x_axis_label = "state location",
                        y_axis_label = "Number of candidate",
                        title="Number of candidate vs state location",
                        x_minor_ticks=20,  #optional
                        x_range = source.data["x"],
                        y_range= ranges.Range1d(start=0,end=100))
                labels = LabelSet(x='x', y='y', text='y', level='glyph',
                        x_offset=-2.5, y_offset=0, source=source,render_mode='canvas' )# offset to adjust the height of labels

                plot3.vbar(source=source,x='x',top='y',legend="x",bottom=0,width=0.3,color='color')#color optional
                
                plot3.legend.orientation = "horizontal"
                plot3.legend.location = "top_right"

                plot3.add_layout(labels)
######################################################################################################################
                pagol4=df["district_location"].value_counts()
                lang,counts = list(pagol4.index),list(pagol4.values)
                
                counts_per=[round((counts[i]/sum(counts))*100) for i in range(len(counts))]


                p4= figure(x_range=lang, plot_height=450, title="Number of candidate vs District location")
                source = ColumnDataSource(dict(x=lang,y=counts_per,color=Spectral6))

                plot4= figure(plot_width=600, plot_height=250, tools="save",# plot section optional
                        x_axis_label = "District location",
                        y_axis_label = "Number of candidate",
                        title="Number of candidate vs District location",
                        x_minor_ticks=20,  #optional
                        x_range = source.data["x"],
                        y_range= ranges.Range1d(start=0,end=100))
                labels = LabelSet(x='x', y='y', text='y', level='glyph',
                        x_offset=-2.5, y_offset=0, source=source,render_mode='canvas' )# offset to adjust the height of labels

                plot4.vbar(source=source,x='x',top='y',legend="x",bottom=0,width=0.3,color='color')#color optional
                
                plot4.legend.orientation = "horizontal"
                plot4.legend.location = "top_right"

                plot4.add_layout(labels)
#########################################################################################################################
                xf= df['gender'].value_counts()
                xf= xf.to_dict()
                print(xf)
                data = pd.Series(xf).reset_index(name='value').rename(columns={'index':'country'})
                data['angle'] = data['value']/data['value'].sum() * 2*pi
                if len(xf)==2:
                        data['color'] =["palegreen","navy"]
                elif len(xf)==3:
                        data['color']=Category10[len(xf)]
                elif len(xf)==1:
                        data['color'] =["palegreen"]
                data['angle'] = data['value']/data['value'].sum() * 2*pi
                data['value']=data['value']/data['value'].sum()
                print(data['angle'])
                
                u= figure(plot_height=300, plot_width=600, title="Pie chart on Gender ", toolbar_location=None,
                        tools="hover", tooltips="@country: @value{%f}")
                u.wedge(x=0, y=1,radius=0.35,
                        start_angle=cumsum('angle',include_zero=True), end_angle=cumsum('angle'),line_color="royalblue",
                        fill_color='color',legend_field='country',source=data)

                u.axis.axis_label=None
                u.axis.visible=False
               
###########################################################################################################

        #############################################################################################       
                w= gridplot([[plot,plot1],[plot2,plot3],[plot4,u]])
                show(w)
                script, div = components(w)

        return render(request,'index.html',{'script' : script , 'div' : div} )
######################################################################################################








#########################################################################################################################

