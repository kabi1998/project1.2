from django.apps import AppConfig


class LiveappConfig(AppConfig):
    name = 'Liveapp'
