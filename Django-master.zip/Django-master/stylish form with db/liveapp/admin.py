from django.contrib import admin
from .models import sampledata

admin.site.register(sampledata)
