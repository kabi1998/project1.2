Follow the code and video step by step and ask your doubts in comments
