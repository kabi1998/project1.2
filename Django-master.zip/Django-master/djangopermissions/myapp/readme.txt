This is the project app of django permissions
