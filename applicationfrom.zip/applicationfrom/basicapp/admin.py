from django.contrib import admin
from .models import subho

# Register your models here.
admin.site.register(subho)