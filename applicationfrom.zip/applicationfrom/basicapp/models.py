from django.db import models

# Create your models here.
class subho(models.Model):
    firstname=models.CharField(max_length=100)
    lastname=models.CharField(max_length=100)
    town=models.CharField(max_length=100)
    district=models.CharField(max_length=100)
    state=models.CharField(max_length=100)