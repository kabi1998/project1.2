from django.shortcuts import render
from django.http import HttpResponse
from .models import subho

# Create your views here.
def index(request):
    if request.method=="POST":
        firstname=request.POST["firstname"]
        lastname=request.POST["lastname"]
        town=request.POST["town"]
        district=request.POST["district"]
        state=request.POST["state"]
        subho_1=subho(firstname=firstname,lastname=lastname,town=town,district=district,state=state)
        subho_1.save()
    return render(request,"ApplicationFrom.html")
